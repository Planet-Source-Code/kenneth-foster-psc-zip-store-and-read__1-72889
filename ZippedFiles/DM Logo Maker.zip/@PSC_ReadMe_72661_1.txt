Title: DM logo Maker V1.0
Description: Make a company logo in seconds, Choose an image, position text and set text properties such as fontstyles and colors and save your result Hope you like this first version.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72661&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
