Title: TitelBar V4.00 Update
Description: This Titelbar ist a complete Replacement for the normal and boring Windows Titelbar.
It act like the original, you can handle and Move, you can Minimize and Close it like the real one.
Simple put it on your Form (Borderstyle of your Form should be 0).
You can change the look by 4 Gradient Color Style, also for two Zones.
There 12 Different Styles (like on the Screenshot).
Your can also add Icons, you can Change the Sytle of your Caption (Color, Shadow, Border etc.)
This time there are 3 Types of Buttons (Close, Minimize, Maximized), you can put your own Icons in the Control as well.
Feel free to Comment and to use it for your Projects.
Update 16.10.2009 - V4.00
Changed the Style Information into english (I tried :)
Added the Maximized Button and Function (as Windows)
Regards J.Pfeffer alias Peppa
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72538&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
