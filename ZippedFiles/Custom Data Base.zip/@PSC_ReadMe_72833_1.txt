Title: Custom Database Program (CD/DVD/etc)
Description: This is a customizable program for creating a CD or DVD list, or a simple database of any other collection you might have. You can specify how many columns of info it holds, and their captions. It stores the info in a flat file, and does not use Access or other DB. Includes an Excel spreadsheet that can load the flat file database into the sheet. (My mobile device has Excel mobile but no DB prog). Requires VB6 maybe? (uses MAPI and RTB), but could easily be modified for VB5. Includes demo DVD data.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72833&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
