Title: ZipSearch 1.2 * Search File Names &amp; Content in File System &amp; Zip Files
Description: ZipSearch simulates the Windows search utility and extends on it to include zip file contents. Searches are based on name matching, and can also perform date and size filtering. Limited wildcard characters are supported for matching of folder and file names. Searches within file text supports multi-line, case-sensitive and case-insensitive matching, as well as whole-word-only searches. This tool can also perform searches within the text content of zipped files.
**********************************************
It can search within multiple locations simultaneously, and search to any sub-folder depth. Files and folders can be selected for exclusion from searches. Also, it catalogues all searched locations so subsequent searches are lightning fast.
**********************************************
This utility does not discard the results of the searches it performs, allowing the navigation of search results within the utility without losing the original list of results. Up to thirty searches can be performed before the oldest results are over-written by subsequent searches.
**********************************************
More advanced search filtering can be achieved by merging the common items from the result of the multiple searches.
**********************************************
ZipSearch uses Info-Zip's Unzip32.dll to open zipped files for content searching and making zipped files available for display. Unzip32.dll is freely available at www.info-zip.org.
ftp://tug.ctan.org/tex-archive/tools/zip/info-zip/WIN32/unz552dN.zip
**********************************************
Contributors: XP Styles thanks to Amer Tahir. Memory Manipulation Library TLB thanks to John Underhill. Auto-complete thanks to Dan Redding. String&#160;comparison&#160;thanks to&#160;Ralph&#160;Eastwood. Thanks also to Norm Cook for inspiration from his brilliant ListView-FileListBox.
**********************************************
You are free to use this search utility for any purpose, but by doing so you fully accept that you receive absolutely no warranties expressed or implied.
**********************************************
1.1.2 - 6 Aug - Implemented ability to replace removable media then list and search new content. Optimized sorting compare function. Added clean-up code to remove temporary extracted files. Added comments to search form and class.
**********************************************
1.1.3 - 11 Aug - Thanks to Alan Corby, fix for UNIX zips that fail to record the uncompressed file size in the zip archive. Also added by request elapsed time of searches.
**********************************************
1.1.4 - 12 Aug - Search history bug fix, introduced in 1.1.2.
**********************************************
1.1.5 - 10 Sept - Added icon in system tray on minimize. Minor fixes and improvements. Added ability to search multi-line text content.
**********************************************
1.1.6 - 30 Sept - Added auto-complete to paths. Minor improvements. Added option to list full paths in listview.
**********************************************
1.1.7 - 11 Oct - Much improved registered path checked-style listbox. Added search groups. Increased registered paths and search history to 30 each.
**********************************************
1.1.8 - 22 Oct - Enabled insertion/deletion of registered search paths without losing cache. File delete bug fix. Added Ralph/Rd fast text compare to list sorting. Now remembers listview column widths.
**********************************************
1.1.9 - 12 Nov - Group registry bug fix. Fixed stubborn ShellExecute(Ex) bug! Includes Win95/Vb5 compatible version.
**********************************************
1.2 - 22 Dec 09 - Fixed another history bug! Added option to add ZipSearch to explorers folders context menu. Added option to clear search results.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72288&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
