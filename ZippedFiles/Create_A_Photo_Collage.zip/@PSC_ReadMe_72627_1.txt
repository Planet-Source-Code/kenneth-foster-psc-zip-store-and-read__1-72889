Title: Create A Photo Collage (Update)
Description: This could be the start of a photo collage program. Fairly small amount of code.Things to add could be rotatiable text, templates, or background patterns. Can only save as bitmap at the present.(Was too lazy to add the others) Hope you find it useful.
Update:Added Save Jpeg,add text and background, can undo now. Let me know what you think.
Update: add shapes.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72627&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
