Title: Screen Calipers Revisited
Description: Re-make of my earlier submission.Changed the graphics and added the connector bar.Commented when needed.Hope you like the new version.If you make any improvements, I'd like to see them.
Added 1/9/07: Now you can select between pixels and twips. Also fixed a couple of bugs.
Revised Code:1/10/07... Redraw much improved and positions and values retained when switching from V to H.
1/12/07..Added color selection and changed some code.
1/13/07...Added Rocky Clarks A+ Screen Zoom to the project. Lets you fine tune measurements easier.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67585&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
